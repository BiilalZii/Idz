# المحفظة الوطنية للهوية 🇩🇿 — Algerian Identity Wallet

تطبيق أندرويد أصلي (Kotlin) للتحقق من الهوية عبر **بطاقة التعريف الوطنية البيومترية الجزائرية (CNIBE)** +
**مطابقة الوجه الحية** — يعمل **محلياً 100% على الجهاز** بدون أي خوادم، وبسياسة **Zero-Capture**
(لا تُحفظ أي صورة على القرص إطلاقاً).

---

## 1. كيف يعمل؟ (التدفق الكامل)

```
┌─────────────────────┐   BAC (رقم المستند + الميلاد + الانتهاء)   ┌──────────────┐
│  بطاقة CNIBE (NFC)  │ ─────────────────────────────────────────── │ هاتف أندرويد │
└─────────────────────┘   ICAO 9303 / IsoDep / DG1 + DG2           └──────┬───────┘
                                                                          │
                              ┌───────────────────────────────────────────┘
                              ▼
                 1) قراءة DG2 (صورة الوجه البيومترية) في الذاكرة فقط
                 2) استخراج بصمة وجه البطاقة عبر MobileFaceNet (TFLite)
                 3) الكاميرا الأمامية: ImageAnalysis فقط (بدون ImageCapture!)
                 4) ML Kit يكشف الوجه → بصمة حية → Cosine Similarity
                 5) 3 إطارات متتالية ناجحة → توليد مفتاح ECDSA في AndroidKeyStore
                 6) تصفير كل البايتات (Zeroization) → فتح قاعدة SQLCipher وتسجيل النجاح
```

### لماذا BAC إجباري؟

شريحة NFC في البطاقة الجزائرية **مقفلة تشفيرياً** (Basic Access Control). لا يمكن قراءة
الصورة من `DG2` بمجرد اللمس — يجب أولاً اشتقاق مفتاح الجلسة من 3 معلومات مطبوعة على البطاقة:

| المعلومة | الصيغة | مثال |
|---|---|---|
| رقم المستند (Document Number) | كما هو مطبوع | `123456789` |
| تاريخ الميلاد | `YYMMDD` | `950101` |
| تاريخ انتهاء الصلاحية | `YYMMDD` | `280101` |

التطبيق يطلبها في الشاشة الرئيسية قبل تقريب البطاقة.

---

## 2. المتطلبات

- **Android Studio** Hedgehog (2023.1.1) أو أحدث + JDK 17
- هاتف أندرويد حقيقي بنظام **Android 8.0+ (API 26)** فيه **NFC** (المحاكي لا يقرأ البطاقات!)
- بطاقة التعريف البيومترية الجزائرية + معرفة بياناتها الثلاث
- (مستحسن) ملف `mobilefacenet.tflite` في `app/src/main/assets/` للدقة الكاملة
  (بدونه يعمل التطبيق بوضع تجريبي بديل — راجع `assets/README.txt`)

---

## 3. التشغيل في 5 خطوات

1. افتح Android Studio ← **Open** ← اختر مجلد `algerian-identity-wallet`
2. انتظر مزامنة Gradle (يتطلب إنترنت أول مرة لتحميل JMRTD و CameraX و ML Kit…)
3. (اختياري للدقة الكاملة) ضع `mobilefacenet.tflite` في `app/src/main/assets/`
4. وصّل هاتفك عبر USB وفعّل **تصحيح USB**، ثم اضغط **Run ▶**
5. على الهاتف:
   - أدخل البيانات الثلاث بصيغة صحيحة
   - فعّل **NFC** من الإعدادات
   - **قرّب البطاقة من ظهر الهاتف** (الهوائي غالباً قرب الكاميرا الخلفية) وثبّتها حتى تنتهي القراءة
   - اضغط **بدء التحقق بالوجه** وانظر للكاميرا الأمامية
   - بعد التطابق اضغط **تأكيد الهوية** ✅

---

## 4. خريطة الملفات

```
algerian-identity-wallet/
├── settings.gradle.kts                  ← المستودعات (google / mavenCentral / jitpack)
├── build.gradle.kts                     ← إصدارات Gradle + Kotlin
├── gradle.properties
├── app/
│   ├── build.gradle.kts                 ← كل الاعتماديات (JMRTD, CameraX, MLKit, TFLite, SQLCipher…)
│   ├── proguard-rules.pro
│   └── src/main/
│       ├── AndroidManifest.xml          ← أذونات NFC + كاميرا + فلتر TECH_DISCOVERED
│       ├── res/xml/nfc_tech_filter.xml  ← فلتر IsoDep
│       ├── res/layout/activity_main.xml ← الواجهة العربية (3 خطوات)
│       ├── res/values/strings.xml       ← كل النصوص العربية
│       ├── assets/README.txt            ← أين تضع نموذج MobileFaceNet
│       └── java/com/wallet/identity/
│           ├── MainActivity.kt                 ← التدفق الكامل + NFC Foreground Dispatch
│           ├── nfc/AlgerianNfcReader.kt        ← BAC + قراءة DG1/DG2 + دعم JP2
│           ├── biometrics/FaceEmbeddingExtractor.kt ← TFLite (حقيقي + وضع بديل)
│           ├── biometrics/LiveFaceMatcher.kt   ← ImageAnalysis + MLKit + Cosine Similarity
│           ├── security/SecurityManager.kt     ← مفتاح KeyStore + تصفير الذاكرة
│           └── db/LocalDatabaseHelper.kt       ← SQLCipher + عبارة مرور في EncryptedSharedPreferences
```

---

## 5. الضمانات الأمنية (مطابقة للمواصفات)

| المبدأ | التطبيق |
|---|---|
| **Zero-Capture** | لا يوجد `ImageCapture` في CameraX إطلاقاً — `ImageAnalysis` فقط + `imageProxy.close()` فور كل إطار |
| **لا صور على القرص** | لا كاش، لا معرض، لا ملفات مؤقتة — كل شيء في RAM |
| **Zeroization** | `wipeSensitiveData()` تصفّر البايتات والبصمات وتمسح الـ Bitmap ثم تستدعي GC |
| **مفتاح عتادي** | ECDSA P-256 داخل `AndroidKeyStore` (TEE/StrongBox) — المادة الخام لا تُستخرج أبداً |
| **قاعدة مشفرة** | SQLCipher بـ AES-256 + عبارة مرور 256-بت مخزنة في `EncryptedSharedPreferences` |
| **بدون نسخ احتياطي** | `allowBackup="false"` + `supportsRtl` للواجهة العربية |
| **محلي 100%** | ML Kit + TFLite على الجهاز — لا إنترنت، لا خوادم، لا تسريب |

> **تصحيح مهم عن المواصفات الأصلية:** المفتاح الخاص العتادي تكون `privateKey.encoded == null`
> دائماً (هذه هي الحماية نفسها!) لذلك لا يمكن استخدامه ككلمة مرور للقاعدة. الحل الصحيح
> المطبق هنا: عبارة مرور عشوائية للقاعدة محفوظة في `EncryptedSharedPreferences`
> (المحمية بدورها بمفتاح في KeyStore)، والمفتاح الخاص يُستخدم للتوقيع فقط.

---

## 6. استكشاف الأخطاء (شائع في الجزائر)

| المشكلة | الحل |
|---|---|
| التطبيق لا يكتشف البطاقة | تأكد أن الهاتف فيه NFC وفعّله من الإعدادات؛ جرّب مواضع مختلفة على ظهر الهاتف (قرب الكاميرا/المنتصف)؛ أزل جراب الهاتف السميك |
| `BAC failed` / فشلت القراءة | تحقق من البيانات الثلاث حرفاً بحرف (الأصفار، ترتيب YYMMDD)؛ ثبّت البطاقة دون تحريك 10–15 ثانية |
| الصورة لا تُفك (`JP2`) | بعض البطاقات تخزن DG2 بصيغة JPEG-2000 — فعّل سطر `jj2000-android` في `app/build.gradle.kts` ثم اربط المفكك في `tryDecodeJp2()` |
| التشابه منخفض دائماً | أضف نموذج `mobilefacenet.tflite` الحقيقي؛ حسّن الإضاءة؛ انزع النظارة الشمسية؛ انظر مباشرة للكاميرا |
| الكاميرا لا تفتح | امنح إذن الكاميرا؛ أغلق التطبيقات الأخرى المستخدمة للكاميرا |
| `SQLCipher` يفشل أول مرة | احذف بيانات التطبيق وأعد التشغيل (عبارة مرور جديدة ستُ generating تلقائياً) |

---

## 7. التطويرات المقترحة التالية

1. **ماسح MRZ بالكاميرا** (ML Kit Text Recognition) لملء البيانات الثلاث تلقائياً بدل الإدخال اليدوي
2. **دعم PACE** (بديل BAC الأحدث) إن اعتمدته إصدارات البطاقة الجديدة
3. **كشف الحيوية ضد الخداع** (Liveness: رمشة/إيماءة + تحليل العمق) قبل المطابقة
4. **توقيع المعاملات** بالمفتاح الخاص (تحدي/استجابة) لإثبات الهوية للتطبيقات الأخرى
5. **سجل تدقيق مشفر** لكل عمليات التحقق مع طابع زمني

---

## 8. التقنيات

Kotlin · Android Native · JMRTD 0.7.34 (ICAO 9303 + BAC) · CameraX 1.3.1 ·
ML Kit Face Detection · TensorFlow Lite 2.14 · SQLCipher 4.5.4 (AES-256) ·
AndroidKeyStore (ECDSA P-256) · EncryptedSharedPreferences · Material 3
