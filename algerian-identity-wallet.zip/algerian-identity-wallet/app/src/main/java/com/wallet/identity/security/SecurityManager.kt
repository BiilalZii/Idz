package com.wallet.identity.security

import android.graphics.Bitmap
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Log
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.PrivateKey
import java.util.Arrays

/**
 * إدارة المفاتيح والمحو الآمن:
 * - توليد مفتاح ECDSA P-256 داخل AndroidKeyStore (مرتبط بالعتاد TEE/StrongBox إن توفر).
 * - المفتاح الخاص لا يغادر الهاتف أبداً (privateKey.encoded == null للحماية).
 * - تصفير كل البايتات الحساسة في الذاكرة (Zeroization) بعد التأكيد.
 */
class SecurityManager {

    companion object {
        private const val TAG = "SecurityManager"
        const val KEY_ALIAS = "AlgerianIdentityLocalKey"
    }

    /** توليد مفتاح خاص عالي الأمان داخل معالج الأمان للهاتف */
    fun generateHardwarePrivateKey(): PrivateKey {
        // احذف أي مفتاح قديم بنفس الاسم لضمان التجديد
        deleteKeyIfExists()

        val keyPairGenerator = KeyPairGenerator.getInstance(
            KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore"
        )
        keyPairGenerator.initialize(
            KeyGenParameterSpec.Builder(
                KEY_ALIAS,
                KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY
            )
                .setDigests(KeyProperties.DIGEST_SHA256)
                // تم التحقق من المستخدم مسبقاً عبر البطاقة + الوجه الحي
                .setUserAuthenticationRequired(false)
                .setInvalidatedByBiometricEnrollment(false)
                .build()
        )
        val keyPair = keyPairGenerator.generateKeyPair()
        Log.i(TAG, "Hardware key generated ✅")
        return keyPair.private
    }

    /** جلب المفتاح الخاص من المخزن (مرجع فقط — المادة الخام لا تُستخرج) */
    fun getPrivateKey(): PrivateKey? {
        return try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            (ks.getEntry(KEY_ALIAS, null) as? KeyStore.PrivateKeyEntry)?.privateKey
        } catch (e: Exception) {
            Log.e(TAG, "getPrivateKey failed: ${e.message}")
            null
        }
    }

    fun deleteKeyIfExists() {
        try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            if (ks.containsAlias(KEY_ALIAS)) {
                ks.deleteEntry(KEY_ALIAS)
                Log.i(TAG, "Old key deleted")
            }
        } catch (ignored: Exception) { }
    }

    /**
     * عملية المحو التام للبيانات (Zeroization):
     * الكتابة فوق المصفوفات بالأصفار + مسح الـ Bitmap + حث الـ GC.
     */
    fun wipeSensitiveData(
        photoBytes: ByteArray?,
        embedding1: FloatArray?,
        embedding2: FloatArray?,
        bitmap: Bitmap? = null
    ) {
        try {
            if (photoBytes != null) Arrays.fill(photoBytes, 0.toByte())
            if (embedding1 != null) Arrays.fill(embedding1, 0.0f)
            if (embedding2 != null) Arrays.fill(embedding2, 0.0f)
            if (bitmap != null && !bitmap.isRecycled) {
                try {
                    bitmap.eraseColor(0)
                } catch (ignored: Exception) { }
                try {
                    bitmap.recycle()
                } catch (ignored: Exception) { }
            }
        } finally {
            // حث مجمع النفايات لتنظيف أي بقايا
            System.gc()
            System.runFinalization()
            Log.i(TAG, "Sensitive data wiped ✅")
        }
    }
}
