package com.wallet.identity.nfc

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.nfc.Tag
import android.nfc.tech.IsoDep
import android.util.Log
import net.sf.scuba.smartcards.CardService
import org.jmrtd.BACKey
import org.jmrtd.PassportService
import org.jmrtd.lds.icao.DG1File
import org.jmrtd.lds.icao.DG2File
import java.io.ByteArrayInputStream
import java.io.InputStream

/**
 * قارئ بطاقة التعريف الوطنية البيومترية الجزائرية (CNIBE)
 * متوافق مع معيار ICAO 9303 + بروتوكول BAC.
 *
 * ملاحظة: الشريحة مقفلة تشفيرياً، ولا يمكن قراءة DG2 (الصورة)
 * إلا بعد doBAC بمفتاح مشتق من:
 *  - رقم المستند + تاريخ الميلاد (YYMMDD) + تاريخ الانتهاء (YYMMDD)
 */
class AlgerianNfcReader {

    data class CardResult(
        val faceBitmap: Bitmap?,
        val rawPhotoBytes: ByteArray?,
        val imageMimeType: String?,
        val dg1DocNumber: String? = null,
        val dg1BirthDate: String? = null,
        val dg1ExpiryDate: String? = null
    )

    companion object {
        private const val TAG = "AlgerianNfcReader"
    }

    fun readCard(
        tag: Tag,
        docNumber: String,
        birthDate: String,   // YYMMDD
        expiryDate: String   // YYMMDD
    ): CardResult? {
        val isoDep = IsoDep.get(tag)
        if (isoDep == null) {
            Log.e(TAG, "Tag is not IsoDep")
            return null
        }
        isoDep.timeout = 15000 // 15 ثانية لاستقرار الاتصال مع البطاقة الجزائرية

        var cardService: CardService? = null
        var rawBytes: ByteArray? = null
        var resultBitmap: Bitmap? = null
        var mimeType: String? = null
        var dg1Doc: String? = null
        var dg1Birth: String? = null
        var dg1Expiry: String? = null

        try {
            val bacKey = BACKey(
                docNumber.trim().replace(" ", ""),
                birthDate.trim(),
                expiryDate.trim()
            )
            Log.i(TAG, "Opening card service + BAC…")
            cardService = CardService.getInstance(isoDep)
            val service = PassportService(
                cardService,
                PassportService.NORMAL_MAX_TRANCEIVE_LENGTH,
                PassportService.DEFAULT_MAX_BLOCKSIZE,
                false,
                false
            )
            service.open()

            // 1) فتح القفل التشفيري عبر BAC
            service.sendSelectApplet(false)
            service.doBAC(bacKey)
            Log.i(TAG, "BAC OK ✅")

            // 2) قراءة DG1 (البيانات النصية) للتحقق المتقاطع — اختياري لكن مفيد
            try {
                val dg1In: InputStream = service.getInputStream(PassportService.EF_DG1)
                val dg1File = DG1File(dg1In)
                val mrz = dg1File.mrzInfo
                dg1Doc = mrz.documentNumber?.replace("<", "")?.trim()
                dg1Birth = mrz.dateOfBirth
                dg1Expiry = mrz.dateOfExpiry
                Log.i(TAG, "DG1 read: doc=$dg1Doc birth=$dg1Birth expiry=$dg1Expiry")
            } catch (e: Exception) {
                Log.w(TAG, "DG1 read failed (non-fatal): ${e.message}")
            }

            // 3) قراءة ملف الصورة البيومترية DG2
            val dg2In: InputStream = service.getInputStream(PassportService.EF_DG2)
            val dg2File = DG2File(dg2In)
            Log.i(TAG, "DG2 faceInfos: ${dg2File.faceInfos.size}")

            // 4) استخراج معلومات الوجه
            outer@ for (faceInfo in dg2File.faceInfos) {
                for (faceImage in faceInfo.faceImageInfos) {
                    val imageLength = faceImage.imageLength
                    mimeType = faceImage.mimeType
                    Log.i(TAG, "Face image: mime=$mimeType len=$imageLength w=${faceImage.width} h=${faceImage.height}")
                    val inStream = faceImage.imageInputStream
                    val bytes = readFully(inStream, imageLength)

                    // فك التشفير إلى Bitmap في الذاكرة الحية فقط
                    var bmp = tryDecodeBitmap(bytes)
                    if (bmp == null && mimeType?.contains("jp2", true) == true) {
                        bmp = tryDecodeJp2(bytes) // يحتاج مكتبة JJ2000 (اختياري)
                    }
                    if (bmp != null) {
                        rawBytes = bytes
                        resultBitmap = bmp
                        break@outer
                    } else {
                        Log.w(TAG, "Bitmap decode failed for this face entry, trying next…")
                    }
                }
            }

            if (resultBitmap == null) {
                Log.e(TAG, "No decodable face image found in DG2")
                return null
            }
            return CardResult(resultBitmap, rawBytes, mimeType, dg1Doc, dg1Birth, dg1Expiry)

        } catch (e: Exception) {
            Log.e(TAG, "readCard failed: ${e.message}", e)
            return null
        } finally {
            try {
                cardService?.close()
            } catch (ignored: Exception) { }
            try {
                isoDep.close()
            } catch (ignored: Exception) { }
        }
    }

    /** قراءة كاملة للبايتات من الـ InputStream */
    private fun readFully(inStream: InputStream, expectedLength: Int): ByteArray {
        val buffer = ByteArray(expectedLength)
        var offset = 0
        while (offset < expectedLength) {
            val read = inStream.read(buffer, offset, expectedLength - offset)
            if (read == -1) break
            offset += read
        }
        return if (offset == expectedLength) buffer else buffer.copyOf(offset)
    }

    /** فك ترميز JPEG العادي */
    private fun tryDecodeBitmap(bytes: ByteArray): Bitmap? {
        return try {
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
        } catch (e: Exception) {
            Log.w(TAG, "BitmapFactory failed: ${e.message}")
            null
        }
    }

    /**
     * فك ترميز JPEG-2000 (JP2) — بعض البطاقات تخزن DG2 بهذه الصيغة
     * و BitmapFactory لا يدعمها. لتفعيلها أضف مكتبة JJ2000 للأندرويد:
     *   implementation("com.github.mobidcon:jj2000-android:1.0")
     * ثم استبدل جسم هذه الدالة بالفك الفعلي.
     */
    private fun tryDecodeJp2(bytes: ByteArray): Bitmap? {
        return try {
            // محاولة ديناميكية: إن وُجدت مكتبة JJ2000 في الـ classpath استخدمها عبر Reflection
            // حتى لا ينكسر البناء بدونها.
            val clazz = Class.forName("jj2000.j2k.decoder.Decoder")
            Log.w(TAG, "JJ2000 found ($clazz) but auto-decode not wired — wire it here if needed.")
            // TODO: اربط مفكك JJ2000 هنا وأعد Bitmap ناتجاً.
            // كحل بديل مؤقت: جرّب ByteArrayInputStream مع BitmapFactory مرة أخرى.
            BitmapFactory.decodeStream(ByteArrayInputStream(bytes))
        } catch (e: ClassNotFoundException) {
            Log.e(TAG, "JP2 image but no JJ2000 lib — add it to app/build.gradle.kts")
            null
        } catch (e: Exception) {
            Log.e(TAG, "JP2 decode failed: ${e.message}")
            null
        }
    }
}
