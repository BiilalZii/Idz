package com.wallet.identity.biometrics

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.util.Log
import androidx.annotation.OptIn
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import java.io.ByteArrayOutputStream
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.sqrt

/**
 * مطابقة الوجه الحية — سياسة Zero-Capture:
 * - يستخدم ImageAnalysis فقط (لا يوجد ImageCapture إطلاقاً → لا ملفات على القرص).
 * - كل إطار يُحلَّل في RAM ثم يُحرَّر فوراً عبر imageProxy.close().
 * - تُستخرج البصمة عبر TFLite وتُقارن بـ Cosine Similarity مع بصمة البطاقة.
 * - يتطلب N إطارات متتالية ناجحة قبل القبول (مقاومة للخداع اللحظي).
 */
class LiveFaceMatcher(
    private val cardFaceEmbedding: FloatArray,
    private val extractor: FaceEmbeddingExtractor,
    private val threshold: Float = 0.60f,
    private val requiredMatches: Int = 3,
    private val onMatchSuccess: () -> Unit,
    private val onMatchProgress: (similarity: Float, count: Int) -> Unit = { _, _ -> },
    private val onMatchFailed: (String) -> Unit = {}
) : ImageAnalysis.Analyzer {

    companion object {
        private const val TAG = "LiveFaceMatcher"
    }

    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .build()
    )

    private var consecutiveMatches = 0
    private val successFired = AtomicBoolean(false)

    @OptIn(ExperimentalGetImage::class)
    override fun analyze(imageProxy: ImageProxy) {
        if (successFired.get()) {
            imageProxy.close()
            return
        }
        val mediaImage = imageProxy.image
        if (mediaImage == null) {
            imageProxy.close()
            return
        }

        val rotation = imageProxy.imageInfo.rotationDegrees
        val inputImage = InputImage.fromMediaImage(mediaImage, rotation)

        detector.process(inputImage)
            .addOnSuccessListener { faces ->
                if (successFired.get()) return@addOnSuccessListener
                if (faces.isEmpty()) {
                    consecutiveMatches = 0
                    onMatchProgress(0f, 0)
                    return@addOnSuccessListener
                }
                try {
                    // أكبر وجه في الكادر
                    val face = faces.maxByOrNull {
                        it.boundingBox.width() * it.boundingBox.height()
                    } ?: faces[0]

                    // تحويل الإطار إلى Bitmap في الذاكرة فقط (لا حفظ)
                    val frameBitmap = imageProxyToBitmap(imageProxy)
                    if (frameBitmap == null) {
                        onMatchFailed("تعذر تحويل الإطار")
                        return@addOnSuccessListener
                    }

                    // استخراج بصمة الوجه الحي ومقارنتها
                    val liveEmbedding = extractor.extractFromBitmap(
                        frameBitmap,
                        mapBoxToBitmap(face.boundingBox, imageProxy, frameBitmap)
                    )
                    // تنظيف صورة الإطار فوراً
                    frameBitmap.eraseColor(0)
                    frameBitmap.recycle()

                    val similarity = cosineSimilarity(cardFaceEmbedding, liveEmbedding)
                    // تصفير بصمة الإطار الحي فور المقارنة
                    java.util.Arrays.fill(liveEmbedding, 0f)

                    if (similarity >= threshold) {
                        consecutiveMatches++
                        onMatchProgress(similarity, consecutiveMatches)
                        if (consecutiveMatches >= requiredMatches && successFired.compareAndSet(false, true)) {
                            Log.i(TAG, "MATCH ✅ similarity=$similarity")
                            onMatchSuccess()
                        }
                    } else {
                        consecutiveMatches = 0
                        onMatchProgress(similarity, 0)
                    }
                } catch (e: Exception) {
                    Log.w(TAG, "analyze error: ${e.message}")
                    onMatchFailed(e.message ?: "خطأ في المعالجة")
                }
            }
            .addOnFailureListener {
                onMatchFailed(it.message ?: "خطأ في كشف الوجه")
            }
            .addOnCompleteListener {
                // إتلاف وتحرير الإطار فوراً من الذاكرة دون أي حفظ
                imageProxy.close()
            }
    }

    /** تحويل YUV_420_888 إلى Bitmap مع التدوير الصحيح — في الذاكرة فقط */
    private fun imageProxyToBitmap(proxy: ImageProxy): Bitmap? {
        return try {
            val image = proxy.image ?: return null
            val planes = image.planes
            val y = planes[0].buffer
            val u = planes[1].buffer
            val v = planes[2].buffer
            val ySize = y.remaining()
            val uSize = u.remaining()
            val vSize = v.remaining()
            val nv21 = ByteArray(ySize + uSize + vSize)
            y.get(nv21, 0, ySize)
            v.get(nv21, ySize, vSize)
            u.get(nv21, ySize + vSize, uSize)

            val yuvImage = YuvImage(nv21, ImageFormat.NV21, image.width, image.height, null)
            val out = ByteArrayOutputStream()
            yuvImage.compressToJpeg(Rect(0, 0, image.width, image.height), 90, out)
            val jpegBytes = out.toByteArray()
            // تصفير مصفوفة NV21 فوراً
            java.util.Arrays.fill(nv21, 0.toByte())
            var bmp = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size)
                ?: return null
            java.util.Arrays.fill(jpegBytes, 0.toByte())

            val rotation = proxy.imageInfo.rotationDegrees
            if (rotation != 0) {
                val matrix = Matrix().apply { postRotate(rotation.toFloat()) }
                // الكاميرا الأمامية تحتاج عكساً أفقياً للمطابقة الصحيحة
                matrix.postScale(-1f, 1f, bmp.width / 2f, bmp.height / 2f)
                val rotated = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, matrix, true)
                bmp.recycle()
                bmp = rotated
            }
            bmp
        } catch (e: Exception) {
            Log.w(TAG, "yuv->bitmap failed: ${e.message}")
            null
        }
    }

    /** إسقاط مربع ML Kit على أبعاد الـ Bitmap (تقريبي وآمن الحدود) */
    private fun mapBoxToBitmap(box: Rect, proxy: ImageProxy, bmp: Bitmap): Rect {
        return try {
            val rotation = proxy.imageInfo.rotationDegrees
            val srcW: Int
            val srcH: Int
            if (rotation == 90 || rotation == 270) {
                srcW = proxy.height; srcH = proxy.width
            } else {
                srcW = proxy.width; srcH = proxy.height
            }
            val scaleX = bmp.width.toFloat() / srcW.toFloat()
            val scaleY = bmp.height.toFloat() / srcH.toFloat()
            Rect(
                (box.left * scaleX).toInt().coerceIn(0, bmp.width - 1),
                (box.top * scaleY).toInt().coerceIn(0, bmp.height - 1),
                (box.right * scaleX).toInt().coerceIn(1, bmp.width),
                (box.bottom * scaleY).toInt().coerceIn(1, bmp.height)
            )
        } catch (e: Exception) {
            box
        }
    }

    private fun cosineSimilarity(v1: FloatArray, v2: FloatArray): Float {
        val n = minOf(v1.size, v2.size)
        if (n == 0) return 0f
        var dot = 0f
        var normA = 0f
        var normB = 0f
        for (i in 0 until n) {
            dot += v1[i] * v2[i]
            normA += v1[i] * v1[i]
            normB += v2[i] * v2[i]
        }
        return if (normA > 0 && normB > 0) dot / (sqrt(normA) * sqrt(normB)) else 0f
    }
}
