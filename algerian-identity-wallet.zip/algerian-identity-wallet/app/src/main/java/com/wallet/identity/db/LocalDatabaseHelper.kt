package com.wallet.identity.db

import android.content.Context
import android.util.Base64
import android.util.Log
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import net.sqlcipher.database.SQLiteDatabase
import net.sqlcipher.database.SQLiteOpenHelper
import java.security.SecureRandom

/**
 * قاعدة البيانات المحلية المشفرة (SQLCipher + AES-256).
 *
 * ملاحظة أمنية مهمة: المفتاح الخاص داخل AndroidKeyStore لا يمكن استخراج
 * مادته الخام (encoded == null) لذلك لا يُستخدم مباشرة ككلمة مرور للقاعدة.
 * بدلاً من ذلك نولّد عبارة مرور عشوائية قوية (256-بت) ونخزنها في
 * EncryptedSharedPreferences، وهي بدورها محمية بمفتاح MasterKey في KeyStore.
 * المفتاح الخاص يُستخدم للتوقيع فقط، وعبارة المرور لفتح القاعدة.
 */
class LocalDatabaseHelper(context: Context) :
    SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val TAG = "LocalDB"
        private const val DATABASE_NAME = "local_identity.db"
        private const val DATABASE_VERSION = 1

        private const val PREFS_FILE = "secure_prefs"
        private const val PREF_DB_PASSPHRASE = "db_passphrase_b64"

        /** جلب عبارة المرور أو توليدها وتخزينها مشفرة عند أول تشغيل */
        fun getOrCreatePassphrase(context: Context): String {
            val masterKey = MasterKey.Builder(context)
                .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                .build()
            val prefs = EncryptedSharedPreferences.create(
                context,
                PREFS_FILE,
                masterKey,
                EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            )
            prefs.getString(PREF_DB_PASSPHRASE, null)?.let { return it }

            val random = ByteArray(32) // 256-بت
            SecureRandom().nextBytes(random)
            val passphrase = Base64.encodeToString(random, Base64.NO_WRAP)
            java.util.Arrays.fill(random, 0.toByte())
            prefs.edit().putString(PREF_DB_PASSPHRASE, passphrase).apply()
            Log.i(TAG, "New DB passphrase generated + stored encrypted ✅")
            return passphrase
        }
    }

    private var libsLoaded = false

    private fun ensureLibsLoaded(ctx: Context) {
        if (!libsLoaded) {
            SQLiteDatabase.loadLibs(ctx)
            libsLoaded = true
        }
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS local_wallet_auth (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                auth_status TEXT NOT NULL,
                last_verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
            """.trimIndent()
        )
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // ترقيات مستقبلية هنا
    }

    /** فتح القاعدة المشفرة بعبارة المرور المخزنة بأمان */
    fun openEncryptedDatabase(context: Context): SQLiteDatabase {
        ensureLibsLoaded(context.applicationContext)
        val passphrase = getOrCreatePassphrase(context.applicationContext)
        return getWritableDatabase(passphrase)
    }

    /** تسجيل نجاح التحقق (بدون أي بيانات شخصية — حالة فقط) */
    fun markVerified(db: SQLiteDatabase) {
        db.execSQL("INSERT INTO local_wallet_auth (auth_status) VALUES ('VERIFIED_SUCCESS')")
    }
}
