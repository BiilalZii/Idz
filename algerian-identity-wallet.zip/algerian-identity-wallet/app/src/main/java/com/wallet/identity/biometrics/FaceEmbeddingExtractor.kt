package com.wallet.identity.biometrics

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Rect
import android.util.Log
import org.tensorflow.lite.Interpreter
import org.tensorflow.lite.support.common.FileUtil
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

/**
 * مستخرج البصمة الرقمية للوجه (Face Embeddings 192 بُعداً)
 * باستخدام نموذج MobileFaceNet بصيغة TensorFlow Lite يعمل محلياً على الجهاز.
 *
 * - ضع ملف النموذج في: app/src/main/assets/mobilefacenet.tflite
 * - إن لم يوجد الملف يعمل المستخرج في "الوضع التجريبي البديل"
 *   (بصمة رمادية 192 بُعداً) حتى تتمكن من تجربة التدفق كاملاً،
 *   لكن الدقة الكاملة تتطلب النموذج الحقيقي.
 */
class FaceEmbeddingExtractor(context: Context, modelName: String = "mobilefacenet.tflite") {

    companion object {
        private const val TAG = "FaceEmbedding"
        const val INPUT_SIZE = 112
        const val EMBEDDING_SIZE = 192
    }

    private var interpreter: Interpreter? = null
    val isModelLoaded: Boolean get() = interpreter != null

    init {
        try {
            val modelBuffer = FileUtil.loadMappedFile(context, modelName)
            val options = Interpreter.Options().apply {
                setNumThreads(4)
                setUseNNAPI(false) // ثبات أكبر عبر الأجهزة؛ فعّلها إن أردت السرعة
            }
            interpreter = Interpreter(modelBuffer, options)
            Log.i(TAG, "TFLite model loaded ✅ ($modelName)")
        } catch (e: Exception) {
            Log.w(TAG, "TFLite model NOT found, fallback mode: ${e.message}")
            interpreter = null
        }
    }

    /**
     * استخراج البصمة من صورة + مربع الوجه (اختياري).
     * كل المعالجة في الذاكرة الحية فقط — لا حفظ إطلاقاً.
     */
    fun extractFromBitmap(source: Bitmap, boundingBox: Rect? = null): FloatArray {
        val interp = interpreter
        return if (interp != null) {
            extractWithModel(source, boundingBox, interp)
        } else {
            extractFallback(source, boundingBox)
        }
    }

    // ---------- المسار الحقيقي بالنموذج ----------
    private fun extractWithModel(source: Bitmap, box: Rect?, interp: Interpreter): FloatArray {
        val face = cropFace(source, box)
        val resized = Bitmap.createScaledBitmap(face, INPUT_SIZE, INPUT_SIZE, true)
        if (resized !== face) face.recycle()

        val input = ByteBuffer.allocateDirect(1 * INPUT_SIZE * INPUT_SIZE * 3 * 4)
            .order(ByteOrder.nativeOrder())
        val pixels = IntArray(INPUT_SIZE * INPUT_SIZE)
        resized.getPixels(pixels, 0, INPUT_SIZE, 0, 0, INPUT_SIZE, INPUT_SIZE)
        resized.recycle()

        for (px in pixels) {
            val r = ((px shr 16) and 0xFF)
            val g = ((px shr 8) and 0xFF)
            val b = (px and 0xFF)
            // تطبيع MobileFaceNet القياسي: [-1, 1]
            input.putFloat((r - 127.5f) / 128f)
            input.putFloat((g - 127.5f) / 128f)
            input.putFloat((b - 127.5f) / 128f)
        }

        val output = Array(1) { FloatArray(EMBEDDING_SIZE) }
        interp.run(input, output)
        return l2Normalize(output[0])
    }

    // ---------- الوضع التجريبي البديل (بدون نموذج) ----------
    private fun extractFallback(source: Bitmap, box: Rect?): FloatArray {
        // بصمة رمادية 16x12 = 192 بُعداً — كافية لتجربة التدفق، ليست للاعتماد النهائي.
        val face = cropFace(source, box)
        val small = Bitmap.createScaledBitmap(face, 16, 12, true)
        if (small !== face) face.recycle()
        val px = IntArray(16 * 12)
        small.getPixels(px, 0, 16, 0, 0, 16, 12)
        small.recycle()
        val emb = FloatArray(EMBEDDING_SIZE) { i ->
            val p = px[i]
            val gray = (0.299f * ((p shr 16) and 0xFF) +
                    0.587f * ((p shr 8) and 0xFF) +
                    0.114f * (p and 0xFF)) / 255f
            gray * 2f - 1f
        }
        return l2Normalize(emb)
    }

    /** قص الوجه مع هامش 15% ومعالجة الحدود */
    private fun cropFace(source: Bitmap, box: Rect?): Bitmap {
        if (box == null) return source.copy(Bitmap.Config.ARGB_8888, false)
        val marginX = (box.width() * 0.15f).toInt()
        val marginY = (box.height() * 0.15f).toInt()
        val left = max(0, box.left - marginX)
        val top = max(0, box.top - marginY)
        val right = min(source.width, box.right + marginX)
        val bottom = min(source.height, box.bottom + marginY)
        val w = max(1, right - left)
        val h = max(1, bottom - top)
        return try {
            Bitmap.createBitmap(source, left, top, w, h)
        } catch (e: Exception) {
            source.copy(Bitmap.Config.ARGB_8888, false)
        }
    }

    private fun l2Normalize(v: FloatArray): FloatArray {
        var sum = 0f
        for (x in v) sum += x * x
        val norm = sqrt(sum)
        if (norm < 1e-9f) return v
        for (i in v.indices) v[i] /= norm
        return v
    }

    fun close() {
        try {
            interpreter?.close()
        } catch (ignored: Exception) { }
        interpreter = null
    }
}
