package com.wallet.identity

import android.Manifest
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.nfc.NfcAdapter
import android.nfc.Tag
import android.os.Build
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.wallet.identity.biometrics.FaceEmbeddingExtractor
import com.wallet.identity.biometrics.LiveFaceMatcher
import com.wallet.identity.db.LocalDatabaseHelper
import com.wallet.identity.nfc.AlgerianNfcReader
import com.wallet.identity.security.SecurityManager
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

/**
 * التدفق الكامل:
 * 1) المستخدم يدخل بيانات BAC الثلاث → يقرّب بطاقة CNIBE من ظهر الهاتف
 *    → تُقرأ DG2 (صورة الوجه) في الذاكرة فقط.
 * 2) تُستخرج بصمة وجه البطاقة (TFLite) → تُفعَّل الكاميرا الأمامية
 *    → مطابقة حية عبر ImageAnalysis بدون أي حفظ (Zero-Capture).
 * 3) عند 3 إطارات متتالية ناجحة → توليد مفتاح KeyStore + تصفير الذاكرة
 *    → فتح قاعدة SQLCipher المشفرة وتسجيل VERIFIED_SUCCESS.
 */
class MainActivity : AppCompatActivity() {

    private var nfcAdapter: NfcAdapter? = null
    private val nfcReader = AlgerianNfcReader()
    private val securityManager = SecurityManager()
    private var embeddingExtractor: FaceEmbeddingExtractor? = null

    // بيانات حساسة مؤقتة — تُصفَّر فور التأكيد
    private var tempCardBytes: ByteArray? = null
    private var tempCardBitmap: Bitmap? = null
    private var tempFaceEmbedding: FloatArray? = null

    private lateinit var etDocNumber: EditText
    private lateinit var etBirthDate: EditText
    private lateinit var etExpiryDate: EditText
    private lateinit var tvNfcStatus: TextView
    private lateinit var tvMatchStatus: TextView
    private lateinit var previewView: PreviewView
    private lateinit var btnStartCamera: Button
    private lateinit var btnConfirm: Button

    private var cameraProvider: ProcessCameraProvider? = null
    private lateinit var cameraExecutor: ExecutorService
    private lateinit var nfcExecutor: ExecutorService
    private var isFaceMatched = false

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (!granted) {
                Toast.makeText(this, getString(R.string.camera_denied), Toast.LENGTH_LONG).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        etDocNumber = findViewById(R.id.etDocNumber)
        etBirthDate = findViewById(R.id.etBirthDate)
        etExpiryDate = findViewById(R.id.etExpiryDate)
        tvNfcStatus = findViewById(R.id.tvNfcStatus)
        tvMatchStatus = findViewById(R.id.tvMatchStatus)
        previewView = findViewById(R.id.previewView)
        btnStartCamera = findViewById(R.id.btnStartCamera)
        btnConfirm = findViewById(R.id.btnConfirm)

        cameraExecutor = Executors.newSingleThreadExecutor()
        nfcExecutor = Executors.newSingleThreadExecutor()

        // 1) فحص NFC
        nfcAdapter = NfcAdapter.getDefaultAdapter(this)
        if (nfcAdapter == null) {
            tvNfcStatus.text = getString(R.string.nfc_not_supported)
            Toast.makeText(this, getString(R.string.nfc_not_supported), Toast.LENGTH_LONG).show()
        } else if (!(nfcAdapter?.isEnabled == true)) {
            tvNfcStatus.text = getString(R.string.nfc_disabled)
        }

        // 2) تحميل مستخرج البصمة (TFLite)
        embeddingExtractor = FaceEmbeddingExtractor(this)
        if (embeddingExtractor?.isModelLoaded == false) {
            Toast.makeText(this, getString(R.string.model_missing), Toast.LENGTH_LONG).show()
        }

        // 3) إذن الكاميرا
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
        }

        btnStartCamera.setOnClickListener { startLiveVerificationCamera() }
        btnConfirm.setOnClickListener { onIdentityConfirmed() }

        // إن فُتح التطبيق عبر لمس NFC مباشرة
        handleNfcIntent(intent)
    }

    override fun onResume() {
        super.onResume()
        // تفعيل استماع NFC في الواجهة الأمامية
        val adapter = nfcAdapter ?: return
        val intent = Intent(this, javaClass).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP)
        val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            PendingIntent.FLAG_MUTABLE
        } else {
            0
        }
        val pendingIntent = PendingIntent.getActivity(this, 0, intent, flags)
        try {
            adapter.enableForegroundDispatch(this, pendingIntent, null, null)
        } catch (ignored: Exception) { }
    }

    override fun onPause() {
        super.onPause()
        try {
            nfcAdapter?.disableForegroundDispatch(this)
        } catch (ignored: Exception) { }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleNfcIntent(intent)
    }

    // ---------- NFC ----------
    private fun handleNfcIntent(intent: Intent?) {
        if (intent?.action != NfcAdapter.ACTION_TECH_DISCOVERED &&
            intent?.action != NfcAdapter.ACTION_TAG_DISCOVERED
        ) return

        val tag: Tag? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG, Tag::class.java)
        } else {
            @Suppress("DEPRECATION")
            intent.getParcelableExtra(NfcAdapter.EXTRA_TAG)
        }
        if (tag == null) return

        val docNumber = etDocNumber.text.toString().trim()
        val birthDate = etBirthDate.text.toString().trim()
        val expiryDate = etExpiryDate.text.toString().trim()

        if (docNumber.length < 6 || birthDate.length != 6 || expiryDate.length != 6 ||
            !birthDate.all { it.isDigit() } || !expiryDate.all { it.isDigit() }
        ) {
            Toast.makeText(this, getString(R.string.bac_invalid), Toast.LENGTH_LONG).show()
            return
        }

        tvNfcStatus.text = getString(R.string.nfc_reading)
        nfcExecutor.execute {
            val result = nfcReader.readCard(tag, docNumber, birthDate, expiryDate)
            runOnUiThread {
                if (result?.faceBitmap != null && result.rawPhotoBytes != null) {
                    // تخزين مؤقت في الذاكرة فقط
                    tempCardBytes = result.rawPhotoBytes
                    tempCardBitmap = result.faceBitmap
                    // استخراج بصمة وجه البطاقة فوراً
                    tempFaceEmbedding = try {
                        embeddingExtractor?.extractFromBitmap(result.faceBitmap, null)
                    } catch (e: Exception) {
                        null
                    }
                    if (tempFaceEmbedding != null) {
                        tvNfcStatus.text = getString(R.string.nfc_success)
                        btnStartCamera.isEnabled = true
                        Toast.makeText(
                            this,
                            "تمت قراءة البطاقة ✅ — اضغط بدء التحقق بالوجه",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        tvNfcStatus.text = getString(R.string.nfc_failed)
                    }
                } else {
                    tvNfcStatus.text = getString(R.string.nfc_failed)
                    Toast.makeText(this, getString(R.string.nfc_failed), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ---------- الكاميرا والمطابقة الحية ----------
    private fun startLiveVerificationCamera() {
        val cardEmbedding = tempFaceEmbedding
        val extractor = embeddingExtractor
        if (cardEmbedding == null || extractor == null) {
            Toast.makeText(this, getString(R.string.nfc_waiting), Toast.LENGTH_SHORT).show()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            return
        }

        tvMatchStatus.text = getString(R.string.match_running)
        btnStartCamera.isEnabled = false
        isFaceMatched = false

        // عتبة أدق مع النموذج الحقيقي، ومتساهلة قليلاً في الوضع البديل
        val threshold = if (extractor.isModelLoaded) 0.60f else 0.85f

        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            try {
                cameraProvider = cameraProviderFuture.get()

                val preview = Preview.Builder().build().also {
                    it.setSurfaceProvider(previewView.surfaceProvider)
                }

                // تحليل فقط — بدون أي UseCase للالتقاط (NO Capture → لا ملفات)
                val imageAnalyzer = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_YUV_420_888)
                    .build()

                val faceMatcher = LiveFaceMatcher(
                    cardFaceEmbedding = cardEmbedding,
                    extractor = extractor,
                    threshold = threshold,
                    requiredMatches = 3,
                    onMatchSuccess = {
                        runOnUiThread {
                            isFaceMatched = true
                            tvMatchStatus.text = getString(R.string.match_success)
                            btnConfirm.isEnabled = true
                            // إيقاف الكاميرا فور نجاح المطابقة
                            cameraProvider?.unbindAll()
                        }
                    },
                    onMatchProgress = { similarity, count ->
                        runOnUiThread {
                            if (!isFaceMatched) {
                                tvMatchStatus.text =
                                    "🔍 التشابه: ${(similarity * 100).toInt()}%% — إطارات مؤكدة: $count/3"
                            }
                        }
                    },
                    onMatchFailed = { /* تجاهل هادئ أثناء البث */ }
                )

                imageAnalyzer.setAnalyzer(cameraExecutor, faceMatcher)

                val cameraSelector = CameraSelector.DEFAULT_FRONT_CAMERA
                cameraProvider?.unbindAll()
                cameraProvider?.bindToLifecycle(this, cameraSelector, preview, imageAnalyzer)
            } catch (e: Exception) {
                e.printStackTrace()
                tvMatchStatus.text = "خطأ الكاميرا: ${e.message}"
                btnStartCamera.isEnabled = true
            }
        }, ContextCompat.getMainExecutor(this))
    }

    // ---------- التأكيد النهائي ----------
    private fun onIdentityConfirmed() {
        if (!isFaceMatched || tempFaceEmbedding == null) return

        // 1) إيقاف الكاميرا فوراً
        try {
            cameraProvider?.unbindAll()
        } catch (ignored: Exception) { }

        // 2) توليد المفتاح الخاص داخل العتاد
        val privateKey = try {
            securityManager.generateHardwarePrivateKey()
        } catch (e: Exception) {
            Toast.makeText(this, "فشل توليد المفتاح: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }

        // 3) فتح القاعدة المشفرة وتسجيل النجاح (المفتاح للتوقيع، والقاعدة لها عبارة مرورها)
        try {
            val dbHelper = LocalDatabaseHelper(this)
            val db = dbHelper.openEncryptedDatabase(this)
            dbHelper.markVerified(db)
            db.close()
        } catch (e: Exception) {
            Toast.makeText(this, "فشل فتح القاعدة المشفرة: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }

        // 4) المحو التام لكل الآثار المؤقتة من الذاكرة
        securityManager.wipeSensitiveData(tempCardBytes, tempFaceEmbedding, null, tempCardBitmap)
        tempCardBytes = null
        tempFaceEmbedding = null
        tempCardBitmap = null
        isFaceMatched = false

        btnConfirm.isEnabled = false
        btnStartCamera.isEnabled = false
        tvNfcStatus.text = getString(R.string.nfc_waiting)
        tvMatchStatus.text = getString(R.string.verified_done)
        Toast.makeText(this, getString(R.string.verified_done), Toast.LENGTH_LONG).show()
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            cameraProvider?.unbindAll()
        } catch (ignored: Exception) { }
        // محو احترازي عند الخروج
        securityManager.wipeSensitiveData(tempCardBytes, tempFaceEmbedding, null, tempCardBitmap)
        tempCardBytes = null
        tempFaceEmbedding = null
        tempCardBitmap = null
        try {
            embeddingExtractor?.close()
        } catch (ignored: Exception) { }
        try {
            cameraExecutor.shutdown()
            nfcExecutor.shutdown()
        } catch (ignored: Exception) { }
    }
}
