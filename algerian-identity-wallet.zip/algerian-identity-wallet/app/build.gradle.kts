plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.wallet.identity"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.wallet.identity"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
        debug {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    // 1. بروتوكول قراءة البطاقات البيومترية الدولية والجزائرية (ICAO 9303 + BAC)
    implementation("org.jmrtd:jmrtd:0.7.34")
    implementation("net.sf.scuba:scuba-smartcards-j2se:0.0.20")

    // 2. كاميرا أندرويد (تحليل مباشر فقط بدون حفظ - Zero-Capture)
    val cameraxVersion = "1.3.1"
    implementation("androidx.camera:camera-core:$cameraxVersion")
    implementation("androidx.camera:camera-camera2:$cameraxVersion")
    implementation("androidx.camera:camera-lifecycle:$cameraxVersion")
    implementation("androidx.camera:camera-view:$cameraxVersion")

    // 3. كشف الوجه والذكاء الاصطناعي على الجهاز محلياً (بدون خوادم)
    implementation("com.google.mlkit:face-detection:16.1.6")
    implementation("org.tensorflow:tensorflow-lite:2.14.0")
    implementation("org.tensorflow:tensorflow-lite-support:0.4.4")

    // 4. قاعدة البيانات المحلية المشفرة والتشفير
    implementation("net.zetetic:android-database-sqlcipher:4.5.4")
    implementation("androidx.security:security-crypto:1.1.0-alpha06")

    // 5. مكتبات أندرويد الأساسية
    implementation("androidx.core:core-ktx:1.12.0")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.11.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.7.0")

    // 6. (اختياري) فك تشفير صور JPEG-2000 داخل DG2 إن فشل BitmapFactory
    // فعّل هذا السطر إذا كانت بطاقتك تخزن الصورة بصيغة JP2:
    // implementation("com.github.mobidcon:jj2000-android:1.0")
}
