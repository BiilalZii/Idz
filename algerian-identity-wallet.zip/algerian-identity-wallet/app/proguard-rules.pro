# ProGuard rules — Algerian Identity Wallet
-keep class org.jmrtd.** { *; }
-keep class net.sf.scuba.** { *; }
-keep class org.bouncycastle.** { *; }
-dontwarn org.bouncycastle.**
-dontwarn net.sf.scuba.**

-keep class org.tensorflow.lite.** { *; }
-dontwarn org.tensorflow.lite.**

-keep class com.google.mlkit.** { *; }
-dontwarn com.google.mlkit.**

-keep class net.sqlcipher.** { *; }
-keep class net.zetetic.** { *; }

-keep class com.wallet.identity.** { *; }
